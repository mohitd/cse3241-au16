-- INSERT
-- Insert a new book
INSERT INTO Book VALUES (9999999999, 'Literature & Fiction', 'Testr', 10, 2016, 9.99, 1);

-- Insert a new publisher
INSERT INTO Publisher VALUES (100, 'A Fake Publisher', '1100 Publisher Place', '111-111-1111');

-- Insert a new author
INSERT INTO Author VALUES (200, 'Bob Johnson', '1010 Author Avuenue', '222-222-2222', 'bob_johnson@johnson.com');

-- Insert a new customers
INSERT INTO Customer VALUES (200, 'Bill Johnson', '1010 Author Avuenue', 'bill_johnson@johnson.com');

-- DELETE
-- Deleting a book with isbn:
DELETE FROM Course WHERE required_book=1590520734;
DELETE FROM Wrote WHERE ISBN=782140661;
DELETE FROM Purchase WHERE ISBN=345336895;
DELETE FROM Book WHERE ISBN=61161721;

-- Deleting a publisher with pub_id:
DELETE FROM Book WHERE pub_id=16;
DELETE FROM Publisher WHERE pub_id=1;


-- Deleting an Author with auth_id:
DELETE FROM Wrote WHERE auth_id=91;
DELETE FROM Author WHERE auth_id=1;


-- Deleting a customer with cus_id
DELETE FROM Purchases WHERE cus_id=1;
DELETE FROM Customer_Pay_Info WHERE cus_id=1;
DELETE FROM Customer WHERE cus_id=1;
