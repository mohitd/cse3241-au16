-- Give the number of books purchased using a particular type of credit card (i.e. Mastercard, Visa)
SELECT COUNT(*) FROM PaymentInfo pay, Purchase pur, CustomerPaymentInfo cpi
WHERE pur.CustomerID=cpi.CustomerID
AND pay.CreditCardID = cpi.CreditCardID
AND pay.Type = 'Discover';

-- Find the titles of all books by Pratchett that cost less than $10
SELECT Title, Name
FROM Book JOIN Wrote ON Book.Isbn = Wrote.Isbn JOIN Author ON Wrote.AuthorId = Author.AuthorId
WHERE Price < 10 AND Author.Name = 'Terry Pratchett';

-- Give all the titles and their dates of purchase made by a single customer
SELECT Title, PurchaseDate
FROM Customer JOIN Purchase ON Customer.CustomerId = Purchase.CustomerId JOIN Book ON Purchase.Isbn = Book.Isbn
WHERE Customer.CustomerId = 1;

-- Find the titles and ISBNs for all books with less than 5 copies in stock
SELECT Title, Isbn 
FROM Book
WHERE Quantity < 5;

-- Give all the customers who purchased a book by Pratchett and the titles of Pratchett books they purchased
SELECT Customer.CustomerId, Book.Title 
FROM Customer 
	JOIN Purchase ON Customer.CustomerId = Purchase.CustomerId 
	JOIN Book ON Purchase.Isbn = Book.Isbn 
	JOIN Wrote ON Book.Isbn = Wrote.Isbn 
	JOIN Author ON Wrote.AuthorId = Author.AuthorId
WHERE Author.Name = 'Terry Pratchett';

-- Find the total number of books purchased by a single customer
SELECT COUNT(Isbn)
FROM Purchase 
Where CustomerId = 4;

-- Find the customer who has purchased the most books and the total number of books they have purchased
SELECT CustomerId, COUNT(Isbn)
FROM Purchase
GROUP BY CustomerId
ORDER BY COUNT(Isbn) DESC
LIMIT 1;

-- Give the price of all books that are used as textbooks for all courses at a university (unid = EWKLEDVFBX)
SELECT price 
FROM Course c JOIN Book b ON c.RequiredBook=b.Isbn 
WHERE c.UniversityID="EWKLEDVFBX";

-- Get the emails of all customers whose credit card is going to expire before the end of 2016
SELECT Email 
FROM PaymentInfo pay, Customer c, CustomerPaymentInfo cpi
WHERE c.CustomerID=cpi.CustomerID
AND pay.CreditCardID=cpi.CreditCardID
AND DATE('20'+substr(pay.ExpirationDate, 4)+'-'+substr(pay.ExpirationDate, 1, 3) + '31') < DATE('2016-12-31');

-- Provide a list of customer names, along with the total dollar amount each customer has spent
SELECT Customer.Name, SUM(Price) 
FROM Customer, Purchase, Book
WHERE Customer.CustomerId = Purchase.CustomerId
AND Purchase.Isbn = Book.Isbn
GROUP BY Customer.CustomerId;

-- Provide a list of customer names and e-mail addresses for customers who have spent more than the average customer
SELECT Customer.Name, Customer.Email 
FROM Customer, Purchase, Book
WHERE Customer.CustomerId = Purchase.CustomerId
AND Purchase.Isbn = Book.Isbn
GROUP BY Customer.CustomerId
HAVING SUM(Book.Price) > (
		SELECT AVG(spent) 
		FROM 
		(
			SELECT SUM(Book.Price) AS spent 
			FROM Customer, Purchase, Book
			WHERE Customer.CustomerId = Purchase.CustomerId
			AND Purchase.Isbn = Book.Isbn
			GROUP BY Customer.CustomerId
		)
	);

-- Provide a list of the titles in the database and associated total copies sold to customers, 
-- sorted from the title that has sold the most individual copies to the title that has sold the least
SELECT Book.Title, COUNT(*) AS Number_Sold 
FROM Book, Purchase
WHERE Book.Isbn = Purchase.Isbn
GROUP BY Book.Isbn
ORDER BY Number_Sold DESC;

-- Provide a list of the titles in the database and associated dollar totals for copies sold to customers, 
-- sorted from the title that has sold the highest dollar amount to the title that has sold the smallest
SELECT Book.Title, (COUNT(*) * Book.Price) AS Income
FROM Book, Purchase
WHERE Book.Isbn = Purchase.Isbn
GROUP BY Book.Isbn
ORDER BY Income DESC;

-- Find the most popular author in the database (i.e. the one who has sold the most books)
SELECT Author.Name FROM Author
WHERE Author.AuthorId = 
(
	SELECT AuthorId 
	FROM 
	(
		SELECT Author.AuthorId, COUNT(*) AS Number_Sold 
		FROM Book, Purchase, Author, Wrote
		WHERE Book.Isbn = Purchase.Isbn
		AND Book.Isbn = Wrote.Isbn
		AND Wrote.AuthorId = Author.AuthorId
		GROUP BY Author.AuthorId
	)

	order by Number_Sold desc
	limit 1
);

-- Find the most profitable author in the database for this store (i.e. the one who has brought in the most money)
SELECT Name, SUM(Income) AS Income 
FROM 
(
	SELECT Author.AuthorId, Book.Title, Author.Name, (COUNT(*) * Book.Price) AS Income 
	FROM Book, Purchase, Wrote, Author
	WHERE Book.Isbn = Purchase.Isbn
	AND Wrote.Isbn = Book.Isbn
	AND Wrote.AuthorId = Author.AuthorId
	GROUP BY Author.AuthorId, Book.Isbn
)
GROUP BY AuthorId
ORDER BY Income DESC
LIMIT 1;

-- Provide a list of customer information for customers who purchased anything written by the most profitable author in the database
SELECT Customer.* 
FROM Customer, Purchase, Wrote, Book
WHERE Purchase.CustomerId = Customer.CustomerId
AND Purchase.Isbn = Book.Isbn
AND Wrote.Isbn = Book.Isbn
AND Wrote.AuthorId = 
(
	SELECT AuthorId 
	FROM 
	(
		SELECT AuthorId, Name, SUM(Income) AS Income 
		FROM
		(
			SELECT Author.AuthorId, Book.Title, Author.Name, (COUNT(*) * Book.Price) AS Income 
			FROM Book, Purchase, Wrote, Author
			WHERE Book.Isbn = Purchase.Isbn
			AND Wrote.Isbn = Book.Isbn
			AND Wrote.AuthorId = Author.AuthorId
			GROUP BY Author.AuthorId, Book.Isbn
		)
		GROUP BY AuthorId
		ORDER BY Income DESC
		LIMIT 1
	)
);

-- Provide the list of authors who wrote the books purchased by the customers who have spent more than the average customer
SELECT Author.Name FROM Author,Book,Purchase,Wrote
WHERE Author.AuthorId = Wrote.AuthorId
AND Book.Isbn = Wrote.Isbn
AND Purchase.Isbn = Book.Isbn
AND Purchase.CustomerId = 
(
	SELECT Customer.CustomerId 
	FROM Customer, Purchase, Book
	WHERE Customer.CustomerId = Purchase.CustomerId
	AND Purchase.Isbn = Book.Isbn
	GROUP BY Customer.CustomerId
	HAVING SUM(Book.Price) > 
	(
		SELECT AVG(spent) 
		FROM 
		(
			SELECT SUM(Book.Price) AS spent 
			FROM Customer, Purchase, Book
			WHERE Customer.CustomerId = Purchase.CustomerId
			AND Purchase.Isbn = Book.Isbn
			GROUP BY Customer.CustomerId
		)
	)
);
