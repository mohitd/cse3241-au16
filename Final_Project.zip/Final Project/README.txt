Final Project

CSE 3421
David Fuhry
Tu Th 12:45 PM

Wes Darvin
Mohit Deshpande
Eric Hemphill
Nick Meyer

Part 1 
Section 1: Database Description
Section 2: User Manual
Section 3: Checkpoints/*

Part 2
SQLite_Database/*
	1. a_novel_bookstore.db
	2. create.sql
	3. insert.sql
	4. queries.sql
	5. insert_delete.sql

To use any of the SQL scripts, execute the file .sql as a script.
Please note that all of the other SQL scripts depend on create.sql being run first to set up the table schema. 
